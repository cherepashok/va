from DataLoader import CircularDataFrame
from sklearn.externals import joblib

import pandas as pd

from datetime import datetime


#DATA_PATH = '/Volumes/ADATA CH11/himtech/va_project/tags_c'
DATA_PATH = '/Users/dumbfly/PycharmProjects/himtech/data'
MODEL_NAME = '/Users/dumbfly/PycharmProjects/himtech/models_vf'
TAGS_FILE = '/Users/dumbfly/PycharmProjects/himtech/misc/feature_tags.csv'

def main():


    tags = pd.read_csv(TAGS_FILE)
    dc = CircularDataFrame(tags.tag,DATA_PATH)
    df = dc.get_data_frame()
    prediction(df)


def chrom_feature_extract(data,
                          trend_lags=[10, 30, 50, 70],
                          past_lags=[5, 10, 20, 30]):
    """Feature Extraction for chrom data.
    Trends and lagged previous values.
    Returns new DataFrame"""
    result = data.copy()
    # result = result.join([pd.DataFrame(data=(data.shift(lag)).values,
    #                                    index=data.index,
    #                                    columns=data.columns + '_lag_%d' % lag) for lag in past_lags])

    #  some shit comprehension to avoid calulating rolling_mean twice
    result = result.join([pd.DataFrame(data=(rolled_data.shift(1)).values,
                                       index=data.index,
                                       columns=data.columns + '_trend_%d' % trend) \
                          for rolled_data, trend in map(lambda trend: (data.rolling(trend).mean(), trend),
                                                        trend_lags)])
    return result


def prediction(tags_data):
    # Clean data
    print('clean data')
    tags_data = tags_data[tags_data.columns[tags_data.nunique() > 10]]

    NA_THRESHOLD = 0.5
    tags_data = tags_data[
        tags_data.columns[tags_data.count() > NA_THRESHOLD * tags_data.shape[0]]]

    DEFAULT_LAGS = [2, 15, 30, 60, 90, 120]

    print('new feature')
    tags_data_v = chrom_feature_extract(tags_data, trend_lags=DEFAULT_LAGS, past_lags=[])

    print('load model')
    model_name_list = ['model_C12','model_C3','model_iC4','model_iC5','model_nC4','model_nC5','model_sumC6']
    for model in model_name_list:
        print(model)
        try:
            loaded_model = joblib.load(MODEL_NAME+'/'+model)
            print(loaded_model.predict(tags_data_v))
        except:
            pass






def features_list():
    tags_remove = pd.read_csv("tags_remove.csv", delimiter=";", names=["tag", "description"])
    # In[21]:
    descr_tags = pd.read_csv("tags.csv", names=["id", "name", "column", "machine", "type", "description", "date"])
    # In[22]:
    tags_nearest_columns = [x for x in descr_tags['name'].values if 'Q9' not in x and 'QIR' not in x]
    # In[43]:
    tags_nearest_columns = set(tags_nearest_columns) - set(tags_remove.tag.values)
    for elem in tags_nearest_columns:
        print("{}.csv".format(elem))


if __name__ == "__main__":
    main()

