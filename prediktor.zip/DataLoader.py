import os
from heapq import heappush, heappop, heapreplace
import pandas as pd
import collections
from datetime import datetime


class CircularDataFrame:
    df = pd.DataFrame()
    tag_list = []

    def __init__(self,tag_list, TAGS_DIR):
        self.tag_list = tag_list
        self.df = self.load_data(tag_list, TAGS_DIR)



    def load_data(self,tag_list, TAGS_DIR):
        tag_list_data = {}
        for i, tag in enumerate(tag_list):
            try:
                print(i,tag)
                tag_data = pd.read_csv("{}.csv".format(os.path.join(TAGS_DIR, tag)))
                # tag_data['timestamp'] = pd.to_datetime(tag_data['timestamp'], format=DATE_FORMAT)
                tag_data = tag_data[(tag_data.timestamp >= '2016-08-18 00:19:00') & (tag_data.timestamp <= '2017-04-01 14:38:00')]
                #tag_data = tag_data[(tag_data.timestamp >= '2017-01-01 00:00:00') & (tag_data.timestamp <= '2017-04-01 14:38:00')]
                tag_data.set_index("timestamp", inplace=True)
                tag_data = tag_data[tag_data.quality == "Good"]
                tag_list_data[tag] = tag_data.value
            except IOError as e:
                continue

        tags_data = pd.DataFrame.from_dict(tag_list_data, orient="columns")
        tags_data.index = pd.DatetimeIndex(tags_data.index)
        return tags_data

    def add_interval_data(self,new_df):
        self.df = self.df.drop([self.df.index.min()])
        self.df.append(new_df)


    def get_data_frame(self):
        return self.df

# class CircularDataContainer:
#     tags_ts = {}
#
#     m_interval = 300
#     def __init__(self,minutes_interval):
#         self.m_interval = minutes_interval
#
#     def add_elem(self,tag,value):
#         if tag not in self.tags_ts:
#             self.tags_ts[tag] = collections.deque(maxlen=self.m_interval)
#         self.tags_ts[tag].append(value)
#
#
#     def load_from_csv(self, path, tagname):
#         print("Reading - ",tagname)
#         tag_data = pd.read_csv("{}.csv".format(os.path.join(path, tagname)),names=['tag','time','value','quality'])
#         for row in tag_data.values:
#             tag  = row[0]
#             time = row[1]
#             value = row[2] + 1
#             self.add_elem(tag,(time,value))
#
#     def get_df(self):
#
#         df = pd.DataFrame.from_dict(self.tags_ts , orient='columns')
#         return df


# class HeapDataContainer:
#     '''Class loads & stores data from json , csv sources'''
#
#     tagsTS = {}
#
#     DATE_FORMAT = "%Y-%m-%d %H:%M:%S"
#
#     def readCSV(self, path, tagname):
#         print("Reading - ",tagname)
#
#
#         #s = datetime.now()
#         tag_data = pd.read_csv("{}.csv".format(os.path.join(path, tagname)))
#         #e = datetime.now()
#
#         #print(e-s)
#
#
#         #ss = datetime.now()
#         for row in tag_data.values:
#             tag  = row[0]
#             time = row[1]
#             value = row[2] + 1
#             self.addElem(tag,time,value)
#         #ee = datetime.now()
#         # print(ee-ss)
#
#     def getDF(self):
#         self.normalize()
#         td = pd.DataFrame.from_dict(self.tagsTS,orient="columns")
#         return td
#
#
#     def addElem(self,tag,time,value):
#         if tag not in self.tagsTS:
#             self.tagsTS[tag] = []
#         heappush(self.tagsTS[tag], (time,value))
#
#     def pushElem(self,tag,time,value):
#         heapreplace(self.tagsTS[tag],(time,value))
#
#     def heapsort(self, h):
#         return [heappop(h) for i in range(len(h))]
#
#     def normalize(self):
#         for tag in self.tagsTS:
#             self.tagsTS[tag] = self.heapsort(self.tagsTS[tag])
#
#
#     def print(self):
#         self.normalize()
#         for tag in self.tagsTS:
#             for elem in self.tagsTS[tag]:
#                 print(tag,elem[0],elem[1])
